package exam.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exam.DAO.editProfileDAO;
import exam.model.registrationmodel;

@WebServlet("/editProfile1")
public class editProfile1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		HttpSession session1=request.getSession();
		String email_id=(String) session1.getAttribute("email_id");
		String email=request.getParameter("email_id");
		String name=request.getParameter("name");	
		String mobile_no=request.getParameter("mobno");
		String cls=request.getParameter("classno");
		String clss=cls.trim();
		String rl=request.getParameter("rollno");
		String roll=rl.trim();
		System.out.print(roll+","+clss);
		int clss_no=Integer.valueOf(clss);
		System.out.println(request.getParameter("rollno"));
		String security_qn=request.getParameter("secque");
		String security_ans=request.getParameter("secans");
		int school_reg_no=Integer.valueOf(roll);
		registrationmodel r1=new registrationmodel( name,clss_no,school_reg_no,mobile_no,security_qn,security_ans,email);
		
		if(editProfileDAO.modifyStudentDetail(email_id, r1)==true)
		{
			session1.setAttribute("email_id", email);
			rd=request.getRequestDispatcher("indexController");
			rd.forward(request, response);
		}else{
		request.setAttribute("errormsg", "Sorry couldn't update ,please try again later!!");
		rd=request.getRequestDispatcher("index.jsp");
		rd.forward(request, response);
		}
		
		}
		

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
