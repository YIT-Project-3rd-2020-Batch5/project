package exam.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import exam.model.registrationmodel;

public class indexDAO {
	 private static Connection con; 
	  private static PreparedStatement stmt;
	  
	public static void getConnection()
	  {	 	     
	      try 
	      {
	    	 Class.forName("com.mysql.jdbc.Driver");   // Driver should be registered
	    	  con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/examdb","root","");  
	    
	         
	      } 
	      catch (Exception e) 
	      {
	         e.printStackTrace();
	      }
		   
		 
	  }
	  public static void closeConnection()
	  {
		  try{
			  if(con.isClosed()==false)
		          con.close();   // closing the connection
		  }
		  catch(Exception e)
		  { e.printStackTrace();	 }
	  }  
	  
	 
	  public static ArrayList<registrationmodel> getStudentDetail(String email_id)
	  {
		  ArrayList <registrationmodel> student=new ArrayList<registrationmodel>();
		  registrationmodel temp; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select name,u_id,clss_no,school_reg_no,mobile_no from registration where email_id=? "); 
	      stmt.setString(1, email_id);
		  ResultSet rs=stmt.executeQuery();  
		 // System.out.println(branch);
		  while(rs.next())
			  {  		   
			//  System.out.println(rs.getInt(1)+ rs.getString(2)+rs.getString(3)+rs.getString(4)+branch);
			  temp=new registrationmodel(email_id,rs.getString(1),rs.getString(2),rs.getInt(3),rs.getInt(4),rs.getString(5));	
			  student.add(temp); 		  
			  System.out.println(temp);
			  }  
		     closeConnection();	 
		     return student;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }  	  
	  }
}
